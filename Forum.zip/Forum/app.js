App({
    // onLaunch: function () {
        
    // },
    // onShow: function () {

    // },
    // onHide: function () {

    // },
    // globalData: {
    //     
    //     wxCode: ''
    // },
    HASLOGIN: false,  // 用户是否登录
    WXCODE: '',     
    SystemInfo: '',    // 系统信息
    SESSIONID:'',   
    USERINFO:'',    // 微信版用户信息

    debug: true //程序调试
})

// _USERINFO  本地储存版，线上用户信息
