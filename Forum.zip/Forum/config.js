
const hoturl = 'https://2bsapi.360che.com/'

// const bbsurl = 'http://zhy.bbs.360che.com/'


// module.exports = {
//     HOT: hoturl,
//     BBS: bbsurl
// }

module.exports = hoturl
