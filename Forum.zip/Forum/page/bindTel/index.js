var APPS = getApp()
Page({
    data:{
        userinfo:{}
    },
    onLoad:function() {
        this.setData({
            userinfo: APPS.USERINFO
        })
    }

})
